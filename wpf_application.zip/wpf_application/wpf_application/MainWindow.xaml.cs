﻿using System.Security.Policy;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using wpf_application.Models;

namespace wpf_application
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public User user;
        public Login login;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginClick(object sender, RoutedEventArgs e)
        {
            login = new Login();
            login.Closed += userAdatMegjelenitese;
            login.ShowDialog();
        }
        private void userAdatMegjelenitese(object sender, EventArgs e)
        {
            user = login.user;
            if (user!=null)
            {
                emailcim.Content = user.firstName;
            }
            else
            {
                emailcim.Content = "Nincs bejelentkezett felhasználó!";
            }
           
            
        }
    }
}