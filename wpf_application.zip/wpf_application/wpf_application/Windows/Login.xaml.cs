﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using wpf_application.Models;
using wpf_application.Services;

namespace wpf_application
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public HttpClient client;
        public User user { get; private set; }
        public Login()
        {
            InitializeComponent();
            client = new HttpClient();
        }

        private async void  Button_Click(object sender, RoutedEventArgs e)
        {
            if (username.Text != "" && password.Password != "")
            {
                //MessageBox.Show($"{username.Text}:{password.Password}");
                User user=await LoginServices.LoginAsync(client,  username.Text, password.Password);
                MessageBox.Show(user.accessToken);
                this.Close();
            }
            else
            {
                MessageBox.Show("Nem adott meg felhasználói nevet/jelszót");
            }
            this.Close();
        }
    }
}
