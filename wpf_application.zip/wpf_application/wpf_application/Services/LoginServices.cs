﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using wpf_application.Models;

namespace wpf_application.Services
{
    internal class LoginServices
    {
        public static async Task<User>LoginAsync(HttpClient client, string usernamep, string passwordp)
        {
            String url = "https://dummyjson.com/auth/login";
            LoginDTO loginDTO = new LoginDTO()
            {
                username = usernamep,
                password = passwordp
            };
            String jsonlogin=JsonSerializer.Serialize(loginDTO);
            var request = new StringContent(jsonlogin, Encoding.UTF8, "application/json");
            var response=await client.PostAsync(url, request);
            MessageBox.Show(""+response.StatusCode);
            if(!response.IsSuccessStatusCode){
                
                MessageBox.Show( "Hiba:"+response.RequestMessage);
                return null;
            }
            var responseBody = await response.Content.ReadAsStringAsync();
            /*var jsonResponse = JsonDocument.Parse(responseBody);
            var token=jsonResponse.RootElement.GetProperty("accessToken").GetRawText();
            MessageBox.Show(jsonResponse.RootElement.GetRawText());*/
            User user=JsonSerializer.Deserialize<User>(responseBody);
            return user;
        }
        public class LoginDTO
        {
            public string username { get; set; }
            public string password { get; set; }
        }
    }
}
