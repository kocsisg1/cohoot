using csudh;

namespace TestProject1
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            Host h = new Host("dhvx20.csudh.edu;155.135.1.1");
            h.Domain(1);
            Assert.Equal("edu",h.Domain(1));
            Assert.Equal("csudh", h.Domain(2));
            Assert.Equal("dhvx20", h.Domain(3));
        }
        [Fact]
        public void Test2()
        {
            Host h2 = new Host("dhvx20.csudh.edu;155.135.1.1");
            
            Assert.Equal("nincs", h2.Domain(4));
            Assert.Equal("nincs", h2.Domain(5));
            Assert.Equal("nincs", h2.Domain(0));
        }
    }
}