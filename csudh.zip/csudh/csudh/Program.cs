﻿namespace csudh
{
    public class Host
    {
        public String domain { get; private set; }
        public String ipcim { get; private set; }

        public Host(string domain, string ipcim)
        {
            this.domain = domain;
            this.ipcim = ipcim;
        }
        public Host(String sor)
        {
            try
            {
                domain = sor.Split(";")[0];
                ipcim = sor.Split(";")[1];
            }
            catch(Exception)
            {
                domain = "";
                ipcim = "";
            }
            
        }

        public override string? ToString()
        {
            return domain+"-"+ipcim;
        }

        public String Domain(int szint)
        {
            string[] darabok=domain.Split(".");
            if(darabok.Length >= szint && szint>0 && szint<=5)
            {
                return darabok[darabok.Length - szint];
            }
            else
            {
                return "Nincs";
            }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] sorok=File.ReadAllLines("csudh.txt");
            List<Host> hosts = new List<Host>();
            foreach(var sor in sorok.Skip(1))
            {
                hosts.Add(new Host(sor));
                
            }
            foreach(var host in hosts)
            {
                Console.WriteLine(host);
                
            }
            Console.WriteLine("3. feladat: Címek száma: "+hosts.Count);

            Console.WriteLine("5. feladat: ");
            Console.WriteLine("Az első domain felépítése: ");
            for(int i=1; i<=5; i++)
            {
                Console.WriteLine(i+". Szint: "+hosts[0].Domain(i));
            }

            string tableHTML = "<table>";
            tableHTML += "<tr>";
            tableHTML += "<th>Sorszám</th>";
            tableHTML += "<th>Host domain</th>";
            tableHTML += "<th>Host IP címe</th>";
            tableHTML += "<th>1. szint</th>";
            tableHTML += "<th>2. szint</th>";
            tableHTML += "<th>3. szint</th>";
            tableHTML += "<th>4. szint</th>";
            tableHTML += "<th>5. szint</th>";
            tableHTML += "</tr>";

            int sorszam = 0;

            foreach(var host in hosts)
            {
                sorszam++;
                tableHTML += "<tr>";
                tableHTML += $"<td>{sorszam}</td>";
                tableHTML += $"<td>{host.domain}</td>";
                tableHTML += $"<td>{host.ipcim}</td>";
                tableHTML += $"<td>{host.Domain(1)}</td>";
                tableHTML += $"<td>{host.Domain(2)}</td>";
                tableHTML += $"<td>{host.Domain(3)}</td>";
                tableHTML += $"<td>{host.Domain(4)}</td>";
                tableHTML += $"<td>{host.Domain(5)}</td>";
                tableHTML += "</tr>";
            }
            tableHTML += "</table>";

            File.WriteAllText("table.html", tableHTML);
        }
    }
}