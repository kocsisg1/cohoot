﻿using csudh;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace IpcimWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    
    public partial class MainWindow : Window
    {
        public List<Host> hosts = new List<Host>();
        public MainWindow()
        {
            InitializeComponent();

            string[] sorok = File.ReadAllLines("csudh.txt");
            
            foreach (var sor in sorok.Skip(1))
            {
                hosts.Add(new Host(sor));

            }

            datagrid.ItemsSource = hosts;

        }

        private void bevitel_Click(object sender, RoutedEventArgs e)
        {
            hosts.Add(new Host(domainname.Text, ipcimecske.Text));
            datagrid.ItemsSource = null;
            datagrid.ItemsSource = hosts;
        }

        private void mentes_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
